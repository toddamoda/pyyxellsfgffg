"""TBW."""

import attr


def deep_iterable(member_validator, iterable_validator=None):
    """Perform deep validation of an iterable.

    :param member_validator: validator to apply to iterables members.
    :param iterable_validator: validator to apply to iterable itself (optional).
    :raises TypeError: if any sub-validators fail

    ..note::
        This validator will be implemented in `attrs` version 18.3.
    """
    def _wrapper(inst, attr: attr.Attribute, value):
        """TBW."""
        if iterable_validator:
            iterable_validator(inst, attr, value)

        for member in value:
            member_validator(inst, attr, member)

    return _wrapper


def deep_mapping(key_validator, value_validator, mapping_validator=None):
    """Perform deep validation of a dictionary.

    :param key_validator: Validator to apply to dictionary keys
    :param value_validator: Validator to apply to dictionary values
    :param mapping_validator: Validator to apply to top-level mapping attribute (optional)
    :raises TypeError: if any sub-validators fail

    ..note::
        This validator will be implemented in `attrs` version 18.3.
    """
    def _wrapper(inst, attr: attr.Attribute, value):
        """TBW."""
        if mapping_validator is not None:
            mapping_validator(inst, attr, value)

        for key in value:
            key_validator(inst, attr, key)
            value_validator(inst, attr, value[key])

    return _wrapper
