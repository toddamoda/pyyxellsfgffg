"""Aliases for `attr.validators.XXX`."""

import attr


__all__ = ['optional', 'validate_in', 'instance_of']


optional = attr.validators.optional
validate_in = attr.validators.in_
instance_of = attr.validators.instance_of
