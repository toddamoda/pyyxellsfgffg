"""TBW."""

import attr


__all__ = ['is_callable']


def is_callable(instance, attribute: attr.Attribute, value):
    """Check if 'value' is a 'callable'.

    :raises TypeError: if 'value' is not a callable.

    ..note::

        This validator will be implemented in attr version 18.3.
    """
    if not callable(value):
        raise TypeError("{name} must be a callable "
                        "(got {value!r} that is a {actual!r}.".format(name=attribute.name,
                                                                      actual=value.__class__,
                                                                      value=value))
