"""TBW."""

import typing as t

from . import ValidationError
from ..checkers import check_choices, check_range

__all__ = ['get_validate_info', 'validate_range', 'validate_type', 'validate_choices']


def get_validate_info(func: t.Callable):
    """Retrieve the extra information dict from a validator."""
    return getattr(func, 'validate_info', {'error_message': 'Bad value: {} '})


def validate_choices(choices, is_optional=False):
    """Check that the value is one of the allowable choices.

    This routine is compatible with the attr.ib validator argument.
    """
    def _wrapper(inst, att, value):
        """TBW."""
        if value is None and att.default is None and att.init is False:
            return
        if is_optional and value is None:
            return

        if callable(choices):
            info = {
                'error_message': 'Expected: %r, got: {} ' % choices(),
                'choices': choices(),
            }
            setattr(_wrapper, 'validate_info', info)
            choice_list = choices()
        else:
            choice_list = choices

        result = check_choices(choice_list)(value)
        if not result:
            msg = ''
            raise ValidationError(inst.__class__, att.name, value, msg)

    info = {
        'error_message': 'Expected: %r, got: {} ' % choices,
        'choices': choices,
    }
    setattr(_wrapper, 'validate_info', info)

    return _wrapper


def validate_range(min_val: t.Union[float, int],
                   max_val: t.Union[float, int],
                   step: t.Union[float, int] = None,
                   enforce_step: bool = True,
                   is_optional: bool = False):
    """Check that the value is one of the allowable choices.

    This routine is compatible with the attr.ib validator argument.
    """
    def _wrapper(inst, att, value):
        """TBW."""
        if value is None and att.default is None and att.init is False:
            return
        if is_optional and value is None:
            return

        func = check_range(min_val, max_val, step, enforce_step)
        msg = ''
        try:
            result = func(value)
        except Exception as exc:
            msg += 'Exception: %s. ' % str(exc)
            result = False
        if not result:
            extra_info = get_validate_info(func)
            msg += extra_info['error_message'].format(value)
            msg += ', is_optional:' + str(is_optional)
            raise ValidationError(inst, att.name, value, msg)

    info = {
        'error_message': 'Expected value in range: %r to %r in %r steps, got: {} ' % (min_val, max_val, step),
        'min_val': min_val, 'max_val': max_val, 'step': step, 'enforce_step': enforce_step
    }
    setattr(_wrapper, 'validate_info', info)

    return _wrapper


def validate_type(att_type, is_optional: bool = False):
    """TBW.

    :param att_type:
    :param is_optional:
    :return:
    """
    def _wrapper(inst, att, value):
        if is_optional and value is None:
            return

        if not isinstance(value, att_type):
            msg = 'Expected type %r, but got {} ' % att_type
            msg = msg.format(type(value))
            raise ValidationError(inst, att.name, value, msg)

    return _wrapper
