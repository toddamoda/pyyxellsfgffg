"""TBW."""

__all__ = ['ValidationError']


class ValidationError(Exception):
    """Exception thrown by the argument validate function."""

    def __init__(self, func, arg, value, msg=''):
        """TBW."""
        self.func = func
        self.arg = arg
        self.value = value
        self.msg = msg

    def __repr__(self):
        """TBW."""
        return 'ValidationError(%(func)r, %(arg)r, %(value)r, %(msg)r)' % vars(self)

    def __str__(self):
        """TBW."""
        msg = 'Validation failed: %(func)r, arg: %(arg)r, value: %(value)r, msg: %(msg)r'
        msg = msg % vars(self)
        return msg
