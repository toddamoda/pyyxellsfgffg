"""This module implements a esapy core configuration file.

The output may be used to dynamically generate a GUI using the esapy_gui package.
"""
import attr


class Serializer:
    """esapy configuration syntax generator."""

    def __init__(self, attr_class_type):
        """TBW.

        :param attr_class_type:
        """
        self.attr_class_type = attr_class_type

    def serialize(self):
        """Serialize the data model.

        :return: the model meta-data configuration string.
        """
        # TODO: this is a quick hacked implementation. It should be refactored.
        driver_path = None
        context_att = None
        for att in attr.fields(self.attr_class_type):
            context = att.metadata.get('context', None)
            if context:
                context_att = att
                driver_path = context.__module__ + '.' + context.__qualname__
                break

        lines = list()
        lines.append('""""')
        lines.append('Some description')
        lines.append('""""')
        lines.append('')
        lines.append('#: @update=1')
        lines.append('#: @label-width=150')
        lines.append('#: @indicator-width=150')
        if driver_path:
            lines.append('#: @driver=' + driver_path)
        lines.append('#: @config=' + self.attr_class_type.__name__)
        lines.append('')
        section = None
        for att in attr.fields(self.attr_class_type):
            if att == context_att:
                continue

            att_section = att.metadata.get('section')
            if not att_section and not section:
                section = 'section'
                lines.append('#: @section=' + section)

            if att_section and att_section != section:
                section = att_section
                lines.append('#: @section=' + section)

            meta_tags = list()
            meta_tags.append('@indicator=1')
            valid_func = att.metadata.get('validate')
            if valid_func:
                if valid_func.__qualname__.startswith('check_range'):
                    info = getattr(valid_func, 'validate_info')
                    range_str = '@range={min_val!r},{max_val!r},{step!r},{enforce_step:d}'
                    range_str = range_str.format(**info)
                    meta_tags.append(range_str)

                elif valid_func.__qualname__.startswith('check_choices'):
                    info = getattr(valid_func, 'validate_info')
                    range_str = '@range=' + '|'.join(info['choices'])
                    meta_tags.append(range_str)

            value = att.metadata.get('units')
            if value:
                meta_tags.append('@units=' + value)

            value = att.metadata.get('format')
            if value:
                meta_tags.append('@format=' + value)

            value = att.metadata.get('readonly')
            if value:
                meta_tags.append('@entry=0')
                # meta_tags.append('@readonly=1')
                # meta_tags.append('@button=' + 'get')
            else:
                meta_tags.append('@button=' + 'set')

            meta_tags.append('\n#:')

            value = att.metadata.get('on_get')
            if len(value):
                value = value[0].__qualname__.split('.')[-1]
                meta_tags.append('@getter=' + value)

            value = att.metadata.get('on_set')
            if len(value):
                value = value[0].__qualname__.split('.')[-1]
                meta_tags.append('@setter=' + value)

            value = att.metadata.get('label')
            if value:
                meta_tags.append('@label=' + value.replace(' ', '_'))

            lines.append('')
            value = att.metadata.get('doc')
            if value:
                lines.append('#: ' + value)
            lines.append('#: ' + ' '.join(meta_tags))
            lines.append(att.name.lstrip('_') + '=' + repr(att.default))

        buf = '\n'.join(lines)
        return buf
