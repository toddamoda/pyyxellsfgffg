"""This module implements a gui configuration file.

The output may be used to dynamically generate a GUI using the pyxel
web application package.
"""
import attr
import yaml

from esapy_config import state
from esapy_config.funcargs.callable_registry import functions


class Serializer:
    """TBW."""

    def __init__(self, attr_class_type):
        """TBW.

        :param attr_class_type:
        """
        self.attr_class_type = attr_class_type

    def serialize(self, cfg=None):
        """Serialize the data model.

        :return: the yaml configuration string.
        """
        if cfg is None:
            cfg = self.to_dict()
        buf = yaml.dump(cfg, default_flow_style=False)
        return buf

    @staticmethod
    def create_entry_from_func_def(func_def, key_prefix):
        """TBW.

        :param func_def:
        :param key_prefix:
        :return:
        """
        pass

    @staticmethod
    def create_entry_from_metadata(metadata, key, key_prefix, **kwargs):
        """TBW.

        :param metadata:
        :param key:
        :param key_prefix:
        :return:
        """
        def optionally_update_item(tag):
            """TBW."""
            if tag in metadata:
                item[tag] = metadata[tag]
            if tag in kwargs:
                item[tag] = kwargs[tag]

        entry = metadata.get('entry', {'tag': 'input', 'type': 'text'})
        label = metadata.get('label', '')
        if not label:
            label = key
        label.replace('_', ' ').title()
        units = metadata.get('units', '')
        if units:
            label += ' (%s)' % units

        if len(metadata.get('on_set', [])):
            kwargs['button_label'] = metadata.get('button_label', 'Set')

        # readonly = metadata.get('readonly', False)
        # kwargs['entry_count'] = metadata.get('entry_count', [1, 0][bool(readonly)])
        item = {
            'id': key_prefix + '.' + key,
            'label': label,
            'entry': entry,
            # 'enabled': [1, 0][readonly],
        }
        optionally_update_item('indicator_count')
        optionally_update_item('button_label')
        optionally_update_item('button_class')
        optionally_update_item('entry_count')
        if 'readonly' in metadata:
            readonly = metadata.get('readonly', False)
            item['entry_count'] = metadata.get('entry_count', [1, 0][bool(readonly)])

        title = metadata.get('doc', '')
        if title:
            entry['title'] = title

        valid_func = metadata.get('validate')
        if valid_func:
            if valid_func.__qualname__.startswith('check_range'):
                info = getattr(valid_func, 'validate_info')
                entry['tag'] = 'input'
                entry['type'] = 'number'
                entry['min'] = info['min_val']
                entry['max'] = info['max_val']
                entry['step'] = info['step']

            elif valid_func.__qualname__.startswith('check_choices'):
                info = getattr(valid_func, 'validate_info')
                entry['tag'] = 'select'
                entry['options'] = list(info['choices'])

        return item

    @staticmethod
    def create_section_from_func_def(func_def, key_prefix=None):
        """TBW.

        :param func_def:
        :param key_prefix:
        :return:
        """
        items = []
        section = {
            'label': func_def.name,
            'items': items,
        }
        for arg in func_def.arguments:
            item = Serializer.create_entry_from_metadata(func_def.metadata, arg, key_prefix)
            items.append(item)

        return section

    @staticmethod
    def create_section_from_object(obj, key_prefix=None, label=None):
        """TBW.

        :param obj:
        :param key_prefix:
        :return:
        """
        try:
            attr.fields(obj.__class__)
            return Serializer.create_section_from_attr_class(obj.__class__, key_prefix)
        except attr.exceptions.NotAnAttrsClassError:
            items = []
            for key in obj.__getstate__():
                item = Serializer.create_entry_from_metadata({}, key, key_prefix)
                items.append(item)

            sections = [{
                'label': obj.__class__.__name__,
                'items': items
            }]
            return sections

    @staticmethod
    def create_section_from_attr_class(attr_class_type, key_prefix=None):
        """TBW.

        :param attr_class_type:
        :return:
        """
        class_name = attr_class_type.__name__
        if key_prefix is None:
            key_prefix = class_name

        sections = []
        curr_section = None
        items = []
        context_att = None
        for att in attr.fields(attr_class_type):
            if att.metadata.get('context', None):
                continue
            if att == context_att:
                continue

            att_section = att.metadata.get('section')
            if not att_section and not curr_section:
                att_section = class_name + ' Section'

            if att_section and att_section != curr_section:
                items = []
                sections.append({
                    'label': att_section,
                    'items': items
                })
                curr_section = att_section

            key = att.name.lstrip('_')
            item = Serializer.create_entry_from_metadata(att.metadata, key, key_prefix)
            items.append(item)

        cls_qualname = attr_class_type.__module__ + '.' + attr_class_type.__name__
        for key in functions:
            cls_key, name = key.rsplit('.', 1)
            if cls_key == cls_qualname:
                func_def = functions[key]
                meta_tags = {
                    'button_class': 'call',
                    'entry_count': len(func_def.arguments),
                }
                item = Serializer.create_entry_from_metadata(func_def.metadata, name, key_prefix, **meta_tags)
                items.append(item)

        return sections

    def to_dict(self):
        """Construct a dictionary tree of the class.

        :return: the dict representation of the object model class.
        """
        sections = Serializer.create_section_from_attr_class(self.attr_class_type)

        class_name = self.attr_class_type.__name__
        cfg = {'gui': [
            {
                'label': class_name,
                'section': sections
            }
        ]}

        return cfg

    @staticmethod
    def from_obj(name, obj):
        """TBW.

        :param name:
        :param obj:
        :return:
        """
        obj_dict = state.get_state_dict({name: obj})
        keys = state.get_state_ids(obj_dict)

        parent_list = []
        for key in keys:
            parent, att_name = key.rsplit('.', 1)
            if parent not in parent_list:
                parent_list.append(parent)

        section_list = []
        for parent in parent_list:
            container = state.get_value({name: obj}, parent)
            sections = Serializer.create_section_from_attr_class(container.__class__, parent)

            section_list.extend(sections)

        cfg = {
            'gui': [
                {
                    'label': name,
                    'section': section_list
                }
            ]
        }

        return cfg
