"""TBW."""

import importlib

import typing as t

from ..util import extract_module_func_names


def to_callable(name: t.Union[str, t.Callable]) -> t.Callable:
    """Convert a string into an existing callable 'function'.

    :param name: name of the callable to convert.
    :return: the callable object based on 'name'.

    Example::

        >>> to_callable(str)
        <class 'str')
        >>> to callable(str.split)
        <method 'split' of 'str' objects>

        >>> def foo(x, y): pass
        >>> foo
        <function foo at 0x12345>
        >>> to_callable('foo')
        <function foo at 0x12345>
        >>> to_callable(foo)
        <function foo at 0x12345>
    """
    if callable(name):
        return name

    module_name, func_name = extract_module_func_names(name)
    func_names = [func_name]        # type: t.List[str]

    # Import the module and extract the function
    try:
        module = importlib.import_module(module_name)
    except ImportError as exc:
        if not repr(module_name) in exc.args[0]:
            raise

        try:
            module_name2, func_name2 = extract_module_func_names(module_name)
            module = importlib.import_module(module_name2)
        except ImportError as exc:
            if not repr(module_name2) in exc.args[0]:
                raise

            raise AttributeError('Module %r does not exists' % module_name)
        else:
            func_names = [func_name2, *func_names]

    result = module
    for el in func_names:
        if hasattr(result, el):
            result = getattr(result, el)
        else:
            raise AttributeError('%r has no attribute %r' % (result, el))

    if not callable(result):
        raise TypeError("%r object from %r is not callable" % (func_name, func_name))

    return result


def to_tuple(value_type):
    """TBW."""
    def _wrapper(tuple_arg):
        """TBW."""
        values = []
        for value in tuple_arg:
            values.append(value_type(value))
        return tuple(values)

    return _wrapper


def optional(att_type):
    """Allow a attribute to be None or a value that will be initialized based on the type set.

    :param att_type:
    """
    def _wrapper(value):
        if value is None:
            return None
        else:
            return att_type(value)

    return _wrapper
