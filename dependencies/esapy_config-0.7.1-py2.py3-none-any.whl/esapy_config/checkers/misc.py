"""TBW."""

import typing as t


def check_choices(choices: list):
    """TBW.

    :param choices:
    :return:
    """
    def _wrapper(value):
        if value in choices:
            return True
        else:
            # choices may also be (value,label) tuples.
            for option in choices:
                if isinstance(option, tuple):
                    if value in option:
                        return True
        return False

    # NOTE: _wrapper.__closure__[0].cell_contents => ['silicon', 'hxrg', 'other']
    info = {
        'error_message': 'Expected: %r, got: {} ' % choices,
        'choices': choices,
    }
    setattr(_wrapper, 'validate_info', info)
    return _wrapper


def check_range(min_val: t.Union[float, int],
                max_val: t.Union[float, int],
                step: t.Union[float, int] = None,
                enforce_step: bool = False):
    """TBW.

    :param min_val:
    :param max_val:
    :param step:
    :param enforce_step:
    """
    def _wrapper(value):
        """TBW."""
        # Do something
        result = False
        if min_val <= value <= max_val:
            result = True
            if step and enforce_step:
                multiplier = 1
                if isinstance(step, float):
                    # In Python3: 1.2 % 0.1 => 0.0999999999999999
                    # but it should be 0.0
                    # To fix this, we multiply by a factor that essentially
                    # converts the float into an int

                    # get digits after decimal.
                    # NOTE: the decimal.Decimal class cannot do this properly in Python 3.
                    exp = len(format(step, '.8f').strip('0').split('.')[1])
                    multiplier = 10 ** exp
                result = (round(value * multiplier) % round(step * multiplier)) == 0
        return result

    info = {
        'error_message': 'Expected value in range: %r to %r in %r steps, got: {} ' % (min_val, max_val, step),
        'min_val': min_val, 'max_val': max_val, 'step': step, 'enforce_step': enforce_step
    }
    setattr(_wrapper, 'validate_info', info)

    return _wrapper


def check_type_function(att_type, is_optional: bool = False) -> t.Callable[..., bool]:     # added by David
    """TBW.

    :param att_type:
    :param is_optional:
    :return:
    """
    def _wrapper(value) -> bool:
        if is_optional and value is None:
            return True

        if not isinstance(value, att_type):
            return False

        return True
    info = {'error_message': 'Expected type %r, but got {} ' % att_type}
    setattr(_wrapper, 'validate_info', info)

    return _wrapper


def check_tuple_range(min_val: t.Union[float, int],
                      max_val: t.Union[float, int],
                      step: t.Union[float, int] = None,
                      enforce_step: bool = True):
    """TBW."""
    def _wrapper(tuple_arg):
        """TBW."""
        result = True
        for value in tuple_arg:
            result &= check_range(min_val, max_val, step, enforce_step)(value)
        return result

    return _wrapper
