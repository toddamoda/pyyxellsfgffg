"""Utilities for 'esapy_config'."""

import importlib
import string
import typing as t
import warnings
from functools import wraps

__all__ = ['lstrip_one_underscore', 'to_callable']


def deprecated(msg: str):
    """Mark a callable as deprecated.

    :params msg: message to display in the `DeprecationWarning`.

    Example::

        >>> @deprecated(msg='Please use `bar`')
        ... def foo():
        ...     return 'foo'

        >>> foo()
        DeprecationWarning("Function 'foo' is deprecated ! Please use `bar`")
        foo
    """
    def deprecated_func(func: t.Callable) -> t.Callable:
        """Mark a 'function' or 'method' as deprecated."""
        @wraps(func)
        def _deprecated(*args, **kwargs):
            """TBW."""
            warnings.warn(f"Function {func.__name__!r} is deprecated ! {msg}", DeprecationWarning)

            return func(*args, **kwargs)

        return _deprecated

    return deprecated_func


def lstrip_one_underscore(chars: str) -> str:
    """TBW.

    Example::

        >>> lstrip_one_underscore('Hello')
        Hello
        >>> lstrip_one_underscore('_test')
        test
        >>> lstrip_one_underscore('__test')
        _test
    """
    if not isinstance(chars, str):
        raise TypeError("Expecting 'str' as input.")

    head = chars[:1]  # type: str
    tail = chars[1:]  # type: str

    result = head.lstrip('_') + tail
    if not result:
        raise ValueError("Expecting more characters.")

    if result[0] not in string.ascii_letters:
        raise ValueError("Result %r does not start with a letter." % result)

    return result


def extract_module_func_names(name: str) -> t.Tuple[str, str]:
    """TBW.

    :param name:
    :return:
    """
    if not isinstance(name, str):
        raise TypeError("Invalid input: %r" % name)

    if '.' in name:
        module_name, func_name = name.rsplit('.', maxsplit=1)
    else:
        module_name = 'builtins'
        func_name = name

    return module_name, func_name


@deprecated(msg='Please use `esapy_config.converters.to_callable`.')
def to_callable(name: t.Union[str, t.Callable]) -> t.Callable:
    """Convert a string into an existing callable 'function'."""
    if callable(name):
        return name

    module_name, func_name = extract_module_func_names(name)
    func_names = [func_name]        # type: t.List[str]

    # Import the module and extract the function
    try:
        module = importlib.import_module(module_name)
    except ImportError:
        try:
            module_name2, func_name2 = extract_module_func_names(module_name)
            module = importlib.import_module(module_name2)
        except ImportError:
            raise AttributeError('Module %r does not exists' % module_name)
        else:
            func_names = [func_name2, *func_names]

    result = module
    for el in func_names:
        if hasattr(result, el):
            result = getattr(result, el)
        else:
            raise AttributeError('%r has no attribute %r' % (result, el))

    if not callable(result):
        raise TypeError("%r object from %r is not callable" % (func_name, func_name))

    return result
