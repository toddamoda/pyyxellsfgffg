"""TBW."""

import inspect
import typing as t

from ..evaluator import evaluate_reference
from ..validators import get_validate_info, ValidationError


__all__ = ['ArgumentDef', 'validate', 'argument', 'validate_call',
           'validate_arg', 'parameters', 'get_validate_info']


class ArgumentDef:
    """TBW."""

    def __init__(self, **kwargs):
        """TBW."""
        self.doc = kwargs.pop('doc', '')
        self.label = kwargs.pop('label', '')
        self.validate = kwargs.pop('validate', None)
        self.enabled = kwargs.pop('enabled', True)
        self.cast = kwargs.pop('cast', True)
        # extra attributes to mimic attr.ib (this is still experimental)
        self.metadata = kwargs
        self.validator = kwargs.pop('validator', None)
        self.convert = kwargs.pop('convert', None)
        self._type = kwargs.pop('type', None)
        self._default = kwargs.pop('default', None)
        self.func = kwargs.pop('func', None)
        self.func_id = kwargs.pop('func_id', None)
        self.name = kwargs.pop('name', '')

    @property
    def type(self):
        """Get type information.

        First the `type` attribute is checked, then the function annotations
        are checked, then the default value type. If none of these are defined
        then None is returned.
        """
        if self._type is None:
            spec = inspect.getfullargspec(self.func)
            self._type = spec.annotations.get(self.name)
            if self._type is None:
                default_value = self.default
                if default_value is not None:
                    self._type = type(default_value)
        return self._type

    @property
    def default(self):
        """Get default value."""
        spec = inspect.getfullargspec(self.func)
        if spec.defaults is not None:
            start = len(spec.args) - len(spec.defaults)
            default_values = dict(zip(spec.args[start:], spec.defaults))
        else:
            default_values = {}
        return default_values.get(self.name)

    @staticmethod
    def validate_enable(func_id: str, to_set: bool):
        """Set the validation enable state for a set of function argument."""
        for arg_def in parameters[func_id].values():
            arg_def.enabled = to_set

    @staticmethod
    def cast_enable(func_id: str, to_set: bool):
        """Set the validation enable state for a set of function argument."""
        for arg_def in parameters[func_id].values():
            arg_def.cast = to_set

    def apply_convert(self, value):
        """Convert the value.

        :param value:
        :return: the converted value.
        :raises: ValidationError
        """
        try:
            if self.cast:
                arg_type = self.type
                if not isinstance(value, arg_type):
                    value = arg_type(value)

            if self.convert:
                value = self.convert(value)

        except ValueError as other_exc:
            msg = 'Exception: ' + str(other_exc)
            exc = ValidationError(self.func_id, self.name, value, msg)
            raise exc

        return value

    def apply_validator(self, value):
        """Validate the argument value.

        :param value:
        :return:
        :raises: ValidationError
        """
        if self.validate:
            extra_info = get_validate_info(self.validate)
            msg = extra_info['error_message'].format(value)
            try:
                is_valid = self.validate(value)
            except Exception as other_exc:
                msg += 'Exception: ' + str(other_exc)
                is_valid = False

            if not is_valid:
                exc = ValidationError(self.func_id, self.name, value, msg)
                raise exc

        if self.validator:
            validator_list = self.validator
            if not isinstance(self.validator, (list, tuple)):
                validator_list = [self.validator]

            if len(validator_list):
                for validator in validator_list:
                    validator(self.func, self, value)


parameters = {}  # type: t.Dict[str, t.Dict[str, ArgumentDef]]


def validate_arg(func_id: str, name: str, value: t.Any):
    """TBW.

    :param func_id:
    :param name:
    :param value:
    :return:
    """
    param = parameters.get(func_id, {}).get(name)
    if param:
        param.apply_convert(value)
        param.apply_validator(value)


def validate_call(func_id: str,
                  raise_exception: t.Optional[bool] = True,
                  args: t.Optional[list] = None,
                  kwargs: t.Optional[dict] = None):
    """Validate the arguments passed to the callable.

    :param func_id:
    :param raise_exception: optional output list that is appended if validation
        errors are found.
    :param args: mutable list of positional arguments
    :param kwargs: mutable dict of keyword arguments
    :return: a list of exceptions
    :raises: ValidationError
    """
    if args is None:
        args = []

    if kwargs is None:
        kwargs = {}

    errors = []  # type: t.List[ValidationError]

    if callable(func_id):
        func = func_id
        func_id = _get_func_id(func)
    else:
        func = evaluate_reference(func_id)
        # if the @validate decorator is used, extract the validation func.
        func = getattr(func, 'validation_func', func)

    if func_id not in parameters:
        return errors

    params = parameters[func_id]
    spec = inspect.getfullargspec(func)
    for i, name in enumerate(spec.args):
        param = params.get(name)
        if not param:
            continue

        # get value
        value = param.default
        if name in kwargs:
            value = kwargs[name]
        elif i < len(args):
            value = args[i]

        # cast / convert
        try:
            # value = param.apply_convert(value)        # BUG: do not convert float to int during validation!
            if param.enabled:
                param.apply_validator(value)
        except ValidationError as exc:
            if raise_exception:
                raise exc
            errors.append(exc)

        # set value
        if name in kwargs:
            kwargs[name] = value
        elif i < len(args):
            args[i] = value

    return errors


def validate(func: t.Callable):
    """TBW."""
    def _validate(*args, **kwargs):
        """TBW."""
        args = list(args)
        validate_call(func, True, args, kwargs)
        return func(*args, **kwargs)

    setattr(_validate, 'validation_func', func)

    return _validate


def _get_func_id(func):
    """TBW."""
    if _is_bound(func):
        func_id = func.__qualname__  # type: ignore
    else:
        func_id = func.__module__ + '.' + func.__qualname__  # type: ignore
    return func_id


def _is_bound(func: t.Callable):
    """Test if the function reference is a method bound to an class."""
    spec = inspect.getfullargspec(func)
    if len(spec.args) and spec.args[0] == 'self':
        return True
    return False


def argument(name: str, **kwargs):
    """TBW."""
    def _register(func):
        """TBW."""
        func_id = _get_func_id(func)
        if func_id not in parameters:
            parameters[func_id] = {}

        kwargs2 = dict(kwargs)
        kwargs2['name'] = name
        kwargs2['func_id'] = func_id
        kwargs2['func'] = func
        param = ArgumentDef(**kwargs2)
        parameters[func_id][name] = param
        return func

    return _register
