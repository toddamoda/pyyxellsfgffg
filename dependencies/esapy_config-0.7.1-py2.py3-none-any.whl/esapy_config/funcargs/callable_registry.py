"""TBW."""
import inspect
from collections import OrderedDict
import typing as t
from types import MappingProxyType

import attr

functions = OrderedDict()  # type: OrderedDict[str, FunctionDef]

__all__ = ['register', 'register_base_class_functions',
           'functions', 'FunctionDef', 'get_meta_data_value',
           'get_meta_data', 'to_id']


class FunctionDef:
    """TBW."""

    def __init__(self,
                 func: str,
                 arguments: t.Optional[t.Dict[str, t.Any]] = None,
                 name: t.Optional[str] = None,
                 enabled: bool = True,
                 **kwargs) -> None:
        """TBW."""
        if arguments is None:
            arguments = {}

        self.name = name
        self.func = func
        self.enabled = enabled
        self.arguments = arguments
        self.metadata = kwargs

    @staticmethod
    def create(func: t.Union[t.Callable],
               enabled: bool = True,
               name: t.Optional[str] = None,
               ignore_args: t.Optional[list] = None,
               metadata: t.Dict[str, t.Any] = None):
        """TBW.

        :param func:
        :param enabled:
        :param name:
        :param ignore_args:
        :param metadata:
        :return:
        """
        if metadata is None:
            metadata = {}

        if ignore_args is None:
            ignore_args = []

        # if isinstance(func, str):
        #     func = evaluate_reference(func)
        #     if inspect.isclass(func):
        #         func = func()

        if inspect.isfunction(func):
            spec = inspect.getfullargspec(func)
            default_name = func.__qualname__
            module_path = func.__module__

        elif inspect.ismethod(func):
            spec = inspect.getfullargspec(func)
            if func.__name__ == '__call__':
                # Strip out __call__ and use class name
                default_name = func.__qualname__.rsplit('.', 1)[0]
            else:
                default_name = func.__name__
            module_path = func.__module__

        else:
            raise RuntimeError('Cannot create model definition for: %r' % func)

        if spec.defaults is not None:
            start = len(spec.args) - len(spec.defaults)
            values = dict(zip(spec.args[start:], spec.defaults))
        else:
            values = {}

        arguments = {}
        for arg in spec.args:
            arg_type = spec.annotations.get(arg)
            ignore = False
            if arg == 'self':
                ignore = True

            elif arg_type:
                for ignore_arg in ignore_args:
                    if isinstance(ignore_arg, type) and issubclass(arg_type, ignore_arg):
                        ignore = True
                        break
                    elif isinstance(ignore_arg, str) and arg == ignore_arg:
                        ignore = True
                        break

            if not ignore:
                if arg in values:
                    value = values[arg]
                else:
                    value = None
                arguments[arg] = value

        if not name:
            name = default_name

        func_id = module_path + '.' + default_name

        return FunctionDef(func_id, arguments, name, enabled, **metadata)


def register(maybe_func=None,
             ignore_args: t.Optional[bool] = None,
             name: t.Optional[str] = None,
             enabled: t.Optional[bool] = True,
             metadata: t.Dict[str, t.Any] = None):
    """Auto register callable class or function using a decorator."""
    def _add_function_def(func_ref):
        """TBW."""
        func_def = FunctionDef.create(func_ref,
                                      name=name,
                                      enabled=enabled,
                                      ignore_args=ignore_args,
                                      metadata=metadata)

        functions[func_def.func] = func_def

    def _wrapper_func():
        """TBW."""
        _add_function_def(maybe_func)
        return maybe_func

    def _wrapper_class_call(klass):
        """TBW."""
        if inspect.isclass(klass):
            func = klass().__call__
        else:
            func = klass

        _add_function_def(func)
        return klass

    if maybe_func:
        _add_function_def(maybe_func)
        return _wrapper_func
    else:
        return _wrapper_class_call


def get_meta_data(klass, att):
    """Retrieve the attribute metadata."""
    metadata = None
    if isinstance(klass, type):
        klass = klass
    else:
        klass = klass.__class__

    try:
        func_key = klass.__module__ + '.' + klass.__name__ + '.' + att
        if func_key in functions:
            metadata = functions[func_key].metadata
        else:
            atts = attr.fields(klass)
            attribute = getattr(atts, '_' + att)
            if isinstance(attribute.metadata, MappingProxyType):
                attribute.metadata = dict(attribute.metadata)
            metadata = attribute.metadata
    except attr.exceptions.NotAnAttrsClassError:  # NotAnAttrsClassError
        pass
    except AttributeError:
        pass

    return metadata


def get_meta_data_value(obj, att, meta_key, default_value=None):
    """Retrieve the attribute metadata key value."""
    try:
        # TODO: refactor and use get_meta_data function
        func_key = obj.__module__ + '.' + obj.__class__.__name__ + '.' + att
        if func_key in functions:
            metadata = functions[func_key].metadata
        else:
            atts = attr.fields(obj.__class__)
            metadata = getattr(atts, '_' + att).metadata
        value = metadata.get(meta_key, default_value)
    except attr.exceptions.NotAnAttrsClassError:  # NotAnAttrsClassError
        value = default_value
    except AttributeError:
        value = default_value

    return value


def to_id(obj: t.Any, key: t.Union[str, property, t.Callable]) -> str:
    """Convert the key to a class-dot-name str.

    :param obj:
    :param key:
    :return:
    """
    key_id = None
    if isinstance(obj, type):
        klass = obj
    else:
        klass = obj.__class__

    if isinstance(key, str):
        key_id = key
        if '.' not in key and key in klass.__dict__:
            key_id = klass.__name__ + '.' + key

    elif isinstance(key, property):
        classes = [klass]
        classes.extend(klass.__bases__)
        for base_class in classes:
            if key_id:
                break
            for name, ref in base_class.__dict__.items():
                if ref == key:
                    key_id = klass.__name__ + '.' + name
                    break

    elif callable(key):
        key_id = key.__qualname__
        if '>.' in key_id:
            # If a class is defined within a function it ends up looking like this:
            #   'test_to_id.<locals>.MyClass1.set_name'
            # strip out the the parent function name
            key_id = key_id.split('>.')[-1]

        if not key_id.startswith(klass.__name__):
            # this handles the case that the callable is defined in the
            # base class, and the klass type inherits from this base class.
            # example: mwir project => Lakeshore325A(TemperatureControl)
            parts = key_id.split('.')
            if len(parts) == 2 and len(klass.__bases__):
                for base_class in klass.__bases__:
                    if base_class.__name__ == parts[0]:
                        key_id = klass.__name__ + '.' + parts[1]
                        break
    else:
        raise KeyError('Could not convert: %r. Incorrect type.' % key)

    if key_id is None:
        raise KeyError('Could not construct key: %r' % key)

    return key_id


def register_base_class_functions(attr_klass: t.Type):
    """Register base class registered functions with subclass ids."""
    to_add = {}
    cls_key = attr_klass.__module__ + '.' + attr_klass.__qualname__
    for base_class in attr_klass.__bases__:
        base_key = base_class.__module__ + '.' + base_class.__qualname__
        for key in functions:
            if key.startswith(base_key):
                func_key = key.replace(base_key, cls_key)
                if func_key not in functions:
                    to_add[func_key] = functions[key]
    functions.update(to_add)
