"""TBW."""
import functools
import inspect
import typing as t

import attr

try:
    from esapy_dispatcher import dispatcher
except ImportError:
    dispatcher = None

from ..validators import ValidationError

__all__ = ['attr_class', 'attr_def', 'construct_class']


# Create getter/setter
def _get_getter(key: str, inst: t.Any) -> t.Any:
    """TBW.

    :param key:
    :param inst:
    :return:
    """
    att = getattr(attr.fields(type(inst)), key)
    _call_dispatcher(key, inst, 'get')

    hook = att.metadata.get('on_get')
    if hook is not None:
        for func in hook:
            value = func(inst)
            update = att.metadata.get('on_get_update', False)
            if update:
                value = convert_value(inst, att, value)
                setattr(inst, key, value)

    value = getattr(inst, key)

    return value


def _set_setter(key: str, inst: t.Any, value: t.Any):
    """TBW.

    :param key:
    :param inst:
    :param value:
    :return:
    """
    att = getattr(attr.fields(type(inst)), key)
    value = convert_value(inst, att, value)
    if att.validator:
        att.validator(inst, att, value)

    _call_dispatcher(key, inst, 'set', value)

    hook = att.metadata.get('on_set')
    if hook is not None:
        for func in hook:
            func(inst, value)

    value_0 = getattr(inst, key)
    setattr(inst, key, value)

    if value_0 != value:
        _call_dispatcher(key, inst, 'change', value)

        hook = att.metadata.get('on_change')
        if hook is not None and len(hook) > 0:
            for func in hook:
                name = key.lstrip('_')
                func(inst, name, value)


def _call_dispatcher(key: str, inst: t.Any, signal: str, *args: t.Any):
    """Emit the signal to the global dispatcher.

    :param key:
    :param inst:
    :param signal:
    :param args:
    """
    att = getattr(attr.fields(type(inst)), key)
    disp = _get_meta_value(att, 'use_dispatcher')
    if disp:
        dispatcher.emit((id(inst), key), signal)(*args)


def _get_meta_value(
        att: attr.Attribute,
        key: str,
        default_value: t.Optional[t.Any] = None) -> t.Any:
    """Retrieve metadata key if set, else check if the tag is set in the class_metadata dict.

    :param att:
    :param key:
    :param default_value:
    :return:
    """
    value = att.metadata.get(key, None)
    if value is None:
        value = att.metadata.get('class_metadata', {}).get(key, default_value)
    return value


def set_defaults(inst: t.Any):
    """Call the setter property when the class is initialized.

    This is useful when the config object is linked to another
    context object and that object's state needs to be
    synchronised with this config object.

    :param inst:
    """
    atts = attr.fields(inst.__class__)
    for att in atts:
        # get the current value and check if it
        # is different than the default value.
        value = getattr(inst, att.name)  # NOTE: _get_getter is not called!
        value_0 = att.default
        if value == value_0:
            continue

        # if the attribute is read-only, then _set_setter may NOT be called.
        if _get_meta_value(att, 'readonly'):
            continue

        # extract the property name
        prop_name = att.name.lstrip('_')
        if hasattr(inst.__class__, prop_name):
            # reset the __init__ value so that
            # the _on_set handler is called.
            setattr(inst, att.name, value_0)
            setattr(inst, prop_name, value)  # _set_setter called


def _get_dict_state(inst: t.Any) -> t.Dict[str, t.Any]:
    """Get the state of the object as a dictionary of name/value pairs.

    This routine also includes the super class attributes if the
    super class includes the @attr.s or @attr_class decorator.
    The dictionary key entries are the *public* attribute names, i.e.
    without the prepended underscore. No attribute on_get callback
    handlers are called during this operation.

    :param inst:
    :return: the attribute key/value pairs.
    :rtype: dict
    """
    result = {}
    for att in attr.fields(inst.__class__):
        # att.name is the "private" underscore version.
        name = att.name
        value = getattr(inst, name)  # no "on_get" callback handlers are called.
        key = name.lstrip('_')
        if att.init:
            result[key] = value

    return result


def _set_dict_state(inst: t.Any, state: t.Dict[str, t.Any]):
    """Set the new state of the object provided by the `state` dictionary.

    :param inst:
    :param state:
    :return:
    """
    if isinstance(state, dict):
        for key, value in state.items():
            # NOTE: key is the property setter, not the _name
            name = '_' + key
            setattr(inst, name, value)
    else:
        raise RuntimeError('What to do?')


def attr_def(doc: t.Optional[str] = None,
             readonly: t.Optional[bool] = None,  # deprecated
             is_property: t.Optional[bool] = None,
             on_set: t.Optional[t.Callable] = None,
             on_get: t.Optional[t.Callable] = None,
             on_change: t.Optional[t.Callable] = None,
             use_dispatcher: t.Optional[bool] = None,
             on_get_update: t.Optional[bool] = None,
             **kwargs):
    """Class attribute definition.

    :param doc:
    :param readonly:
    :param is_property:
    :param on_get:
    :param on_set:
    :param on_change:
    :param use_dispatcher:
    :param on_get_update:
    :param kwargs: keyword arguments sent to attr.ib
    :return:
    """
    def create_event_handler_list(on_event):
        """Force the passed event list or event item into a list."""
        on_events = []
        if on_event:
            if isinstance(on_event, (list, tuple)):
                on_events.extend(on_event)
            else:
                on_events.append(on_event)
        return on_events

    on_get_list = create_event_handler_list(on_get)
    on_set_list = create_event_handler_list(on_set)
    on_change_list = create_event_handler_list(on_change)

    metadata = kwargs.get('metadata', {})
    metadata['doc'] = doc
    metadata['readonly'] = readonly
    metadata['is_property'] = is_property
    metadata['on_get'] = on_get_list
    metadata['on_set'] = on_set_list
    metadata['on_change'] = on_change_list
    metadata['use_dispatcher'] = use_dispatcher
    metadata['on_get_update'] = on_get_update
    metadata['class_metadata'] = {}

    attr_ib_kwarg_names = [
        'default',
        'validator',
        'repr',
        'cmp',
        'hash',
        'init',
        'convert',
        'metadata',
        'type',
        'converter'
    ]
    # collect all the attr.ib specific kwargs
    kwargs_attr = {}
    for key in attr_ib_kwarg_names:
        if key in kwargs:
            kwargs_attr[key] = kwargs.pop(key)

    if getattr(attr, '__version__', '0.0') <= '17.3.0':
        if 'converter' in kwargs_attr:
            kwargs_attr['convert'] = kwargs_attr.pop('converter')

    # the kwargs left over are user-specific key/value pairs
    # place them in the metadata dict.
    if len(kwargs) > 0:
        raise KeyError('Bad argument: %r' % kwargs)

    metadata.update(kwargs)
    kwargs_attr['metadata'] = metadata

    attrib = attr.ib(**kwargs_attr)

    return attrib


def _construct_private_atts(klass: t.Type, is_property_default=True):
    """Enforce all attributes to be private by prefixing with underscore."""
    bad_atts = {}
    for key, value in klass.__dict__.items():
        cls_name = value.__class__.__name__
        if cls_name == '_CountingAttr':
            if not key.startswith('_'):
                bad_atts[key] = value

    for key, bad_att in bad_atts.items():
        if _get_meta_value(bad_att, 'is_property', is_property_default):
            new_name = '_' + key
            delattr(klass, key)
            setattr(klass, new_name, bad_att)


def _construct_properties(attr_klass: t.Type):
    """TBW.

    :param attr_klass:
    """
    atts = attr.fields(attr_klass)
    for attrib in atts:
        if not _get_meta_value(attrib, 'is_property', True):
            continue
        key = attrib.name
        if key.startswith('_'):
            name = key.lstrip('_')
            f_get = functools.partial(_get_getter, key)
            if attrib.metadata.get('readonly', False):
                f_set = None
            else:
                f_set = functools.partial(_set_setter, key)
            f_del = None
            doc = attrib.metadata.get('doc')
            setattr(attr_klass, name, property(f_get, f_set, f_del, doc))


def _construct_state(attr_klass: t.Type):
    """TBW.

    :param attr_klass:
    """
    setattr(attr_klass, '__getstate__', _get_dict_state)
    setattr(attr_klass, '__setstate__', _set_dict_state)


def _construct_repr(attr_klass: t.Type):
    """TBW."""
    def init_repr(inst):
        args = ''
        for att in attr.fields(inst.__class__):
            name = att.name
            value = getattr(inst, name)
            key = name.lstrip('_')
            if att.init and att.repr:
                if len(args):
                    args += ', '
                args += '%s=%r' % (key, value)
        return '%s(%s)' % (attr_klass.__name__, args)

    setattr(attr_klass, '__repr__', init_repr)


def construct_class(klass: t.Type, **kwargs):
    """Dynamically construct the class type based on attribute properties.

    :param klass: the template class that will be re-constructed.
    :param kwargs:
    :return: reconstruct class type.
    """
    is_prop_def = kwargs.get('is_property', True)
    _construct_private_atts(klass, is_prop_def)

    # force attr.s 'repr' default argument to False
    org_repr_kwargs = kwargs.get('repr', True)
    if is_prop_def and 'repr' not in kwargs:
        kwargs['repr'] = False  # switch off default attr.s __repr__

    # collect all the attr.s kwargs
    attrs_kw_names = [
        # 'maybe_cls',
        'these',  # None
        'repr_ns',  # None
        'repr',  # True
        'cmp',  # True
        'hash',  # None
        'init',  # True
        'slots',  # False
        'frozen',  # False
        'str',  # False
        'auto_attribs',  # False
    ]
    attr_s_kwargs = {}
    for name in attrs_kw_names:
        if name in kwargs:
            attr_s_kwargs[name] = kwargs.pop(name)

    # was: for base_class in klass.__bases__:
    for base_class in inspect.getmro(klass)[1:-1]:
        if hasattr(base_class, '__attrs_class_metadata'):
            base_metadata = getattr(base_class, '__attrs_class_metadata')
            for key in base_metadata:
                if key not in kwargs:
                    kwargs[key] = base_metadata[key]
    setattr(klass, '__attrs_class_metadata', {})
    klass.__attrs_class_metadata.update(kwargs)

    if 'init_set' in kwargs:
        # force the kwargs values specified in the constructor
        # to trigger the 'on_set' hook.
        attr_post_init = getattr(klass, '__attrs_post_init__', None)

        def post_init_set(inst):
            """Call the :func:`set_defaults` to trigger the `on_set` hook."""
            set_defaults(inst)
            if attr_post_init:
                attr_post_init(inst)

        setattr(klass, '__attrs_post_init__', post_init_set)

    attr_klass = attr.s(**attr_s_kwargs)(klass)

    atts = attr.fields(attr_klass)
    for attrib in atts:
        # Use the class decorator remaining kwargs to set the default
        # value for the attribute metadata key setting.
        if 'readonly' in kwargs and attrib.metadata.get('readonly') is None:
            attrib.metadata['class_metadata']['readonly'] = kwargs['readonly']

        if 'use_dispatcher' in kwargs:
            attrib.metadata['class_metadata']['use_dispatcher'] = kwargs['use_dispatcher']

        if 'is_property' in kwargs:
            attrib.metadata['class_metadata']['is_property'] = kwargs['is_property']

        # if 'cast' in kwargs and attrib.metadata.get('cast') is None:
        #     attrib.metadata['class_metadata']['cast'] = kwargs['cast']  # TODO: deprecated

        if 'on_change' in kwargs and kwargs['on_change'] is not None:
            if kwargs['on_change'] not in attrib.metadata['on_change']:
                # ensure no duplicates hooks due to inheritance
                attrib.metadata['on_change'].append(kwargs['on_change'])

    _construct_properties(attr_klass)
    _construct_state(attr_klass)
    if is_prop_def and org_repr_kwargs:
        _construct_repr(attr_klass)

    if 'on_constructed' in kwargs:
        # call the on class constructed hook function.
        kwargs['on_constructed'](attr_klass)

    return attr_klass


def attr_class(maybe_cls: t.Optional[t.Type] = None, **kwargs):
    """TBW.

    :param maybe_cls:
    :return:
    """
    def _wrapper(klass):
        """TBW.

        :param klass:
        :return:
        """
        return construct_class(klass, **kwargs)

    if maybe_cls is None:
        return _wrapper
    else:
        return _wrapper(maybe_cls)

    return _wrapper


def convert_value(inst: t.Any, attrib: attr.Attribute, value: t.Any):
    """TBW.

    :param inst:
    :param attrib:
    :param value:
    :return:
    """
    converter_name = 'converter'
    if getattr(attr, '__version__', '0.0') <= '17.3.0':
        converter_name = 'convert'

    converter = getattr(attrib, converter_name, None)
    if converter:  # type: ignore
        try:
            value = converter(value)  # type: ignore
        except ValueError as convert_exc:
            msg = 'Convert Error: ' + str(convert_exc)
            raise ValidationError(inst.__class__, attrib.name, value, msg)

    # TODO: the following if block is deprecated, use convert instead.
    # if attrib.type and not isinstance(value, attrib.type) and attrib.metadata.get('cast', False):
    #     try:
    #         value = attrib.type(value)
    #     except ValueError as cast_exc:
    #         msg = 'Cast Error: ' + str(cast_exc)
    #         raise ValidationError(inst.__class__, attrib.name, value, msg)
    return value
