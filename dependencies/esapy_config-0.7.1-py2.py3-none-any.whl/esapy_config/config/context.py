"""TBW."""
import attr
import typing as t

from .attribute import convert_value


__all__ = ['Context', 'ContextRemote']


class Context:
    """The context object to reroute the on_set/get callbacks."""

    def __init__(self, func, *args):
        """TBW.

        :param func:
        """
        self.func = func
        self.args = args

    def _get_args(self, *args):
        """TBW."""
        pargs = []
        pargs.extend(self.args)
        pargs.extend(args)
        return pargs

    def _get_context_object(self, inst: t.Any) -> t.Any:
        """TBW.

        :param inst:
        :return:
        """
        # first check if the user specifically defined the context
        for att in attr.fields(type(inst)):
            if att.metadata.get('context'):
                context = getattr(inst, att.name)
                return context

        # second, check if the context class can be matched to the
        # associated method name
        for att in attr.fields(type(inst)):
            context = getattr(inst, att.name)
            if hasattr(context.__class__, self.func.__name__):
                return context

        raise RuntimeError('No context attribute is defined for: %r' % inst)

    def _get_att(self, inst):
        """Retrieve the Attribute associated with the on_get handler of the instance passed.

        :param inst:
        :return:
        """
        for att in attr.fields(type(inst)):
            for on_key in ['on_get']:  # , 'on_set']:
                hook = att.metadata.get(on_key)
                if hook is not None:
                    for func in hook:
                        if func == self:
                            return att

    def _convert(self, inst, value):
        """TBW.

        :param inst:
        :param key:
        :param value:
        :return:
        """
        att = self._get_att(inst)
        if att:
            key = att.name
            value = convert_value(inst, att, value)
            # if att.validator:  # TODO: should the validator be called?
            #     att.validator(inst, att, value)
            setattr(inst, key, value)  # update this model object (no I/O)
        return value

    def __call__(self, inst, *args):
        """TBW.

        :param inst:
        :param args:
        :return:
        """
        context = self._get_context_object(inst)
        pargs = self._get_args(*args)
        func_ref = self.func
        if isinstance(func_ref, property):
            if len(pargs):
                func_ref = func_ref.fset
            else:
                func_ref = func_ref.fget

        value = func_ref(context, *pargs)
        value = self._convert(inst, value)
        return value


class ContextRemote(Context):
    """This class enables remote context objects to be de-referenced.

    The remote procedure calling library (esapy_config) enables anonymous
    classes to be loaded. This means, the class is not known to the client
    at runtime, but the client is allowed to make a remote call assuming
    that the remote method is available.
    """

    def __call__(self, inst, *args):
        """TBW.

        :param inst:
        :param args:
        :return:
        """
        context = self._get_context_object(inst)
        pargs = self._get_args(*args)
        # refer to: esapy_rpc.driver.Driver.__getattr__
        # to see how the next line is magically handled.
        value = getattr(context, self.func)(*pargs)
        value = self._convert(inst, value)
        return value
