"""TBW."""

import hashlib
import importlib
import linecache
from enum import Enum

import attr
import typing as t

__all__ = ['config', 'setting', 'SettingMode']

METADATA_KEY = 'ESAPY_CONFIG'


class SettingMode(Enum):
    """Define if a setting is accessible in a Read/Write or Read only mode."""

    RW = "RW"
    RO = "RO"


@attr.s(frozen=True)
class MetadataSetting:
    """Create metadata for one setting."""

    is_user_setting = attr.ib(type=bool, validator=attr.validators.instance_of(bool))
    mode = attr.ib(
        type=SettingMode, converter=SettingMode, validator=attr.validators.instance_of(SettingMode)
    )
    doc = attr.ib(
        type=t.Optional[str],
        default=attr.validators.optional(attr.validators.instance_of(str)),
    )


def setting(doc: t.Optional[str] = None,
            is_user_setting: bool = False,
            mode: SettingMode = SettingMode.RW,
            **kwargs):
    """Create a new setting.

    :param doc: define documentation for the setting
    :param is_user_setting:
    :param mode: set if the setting is read/write or read-only.
    :key kwargs: other keywords arguments that will be sent to `attr.ib`
    :return:
    """
    if 'metadata' in kwargs:
        metadata = kwargs.pop('metadata')  # type: dict
    else:
        metadata = {}

    metadata[METADATA_KEY] = MetadataSetting(doc=doc,
                                             is_user_setting=is_user_setting,
                                             mode=mode)

    attrib = attr.ib(metadata=metadata, **kwargs)
    return attrib


def get_type_name(obj) -> str:
    """Return the name for a 'type'.

    :param obj:
    :return:

    Example::

        >>> get_type_name(str)
        'str'
        >>> get_type_name(typing.Optional[str])
        typing.Optional[str]
        >>> get_type_name(typing.Tuple[int])
        typing.Tuple[int]
    """
    if not hasattr(obj, '__module__'):
        raise RuntimeError(f"Missing attribute '__module__' for obj {obj!r}")

    module = obj.__module__  # type: str

    if module == 'typing':
        # This is a `typing' object
        origin_type = obj.__origin__

        if origin_type == t.Union:
            # 'typing.Union' object

            if not hasattr(obj, '__args__') or len(obj.__args__) < 2:
                raise TypeError("Expecting at least two elements in `typing.Union` or "
                                "only one element in `typing.Optional`")

            *first_args, last_arg = obj.__args__

            if len(first_args) == 1 and issubclass(last_arg, type(None)):
                # 'typing.Optional' object
                optional_type_str = get_type_name(first_args[0])  # type: str
                result = f'{module}.Optional[{optional_type_str}]'   # type: str

            else:
                # 'typing.Union' object
                result = str(obj)

        else:
            # Other 'typing' object
            result = str(obj)

    elif hasattr(obj, '__qualname__'):
        if module == 'builtins':
            result = obj.__qualname__
        else:
            result = f'{module}.{obj.__qualname__}'

    else:
        raise NotImplementedError

    return result


# TODO: split this function in multiple small and optimized functions. Improve also readability.
def _construct_source_init(attributes: dict, has_post_init: bool = False) -> t.Iterator[str]:
    """Generate source code for '__init__'.

    :param attributes: dictionary of `attr.Attribute` objects.
    :param has_post_init: notified if method '__attrs_post_init__' is implemented.
    :return:
    """
    def _parameters(attributes: dict) -> t.Iterator[str]:
        """Generate the parameters used in the definition of '__init__'.

        Example::

            >>> list(_parameters(attributes))
            ['item1: int', 'item2: float = 3.14', ...]
        """
        for name, att in attributes.items():
            if not att.init:
                continue

            if att.type is None:
                # No 'type' provided
                if att.default is attr.NOTHING:
                    yield f'{name}'
                elif hasattr(att.default, 'factory'):
                    raise NotImplementedError
                else:
                    yield f'{name}=attr_dict[{name!r}].default'
            else:
                # Extract the 'type'
                # type_name = get_type_name(att.type)  # type: str
                type_name = f"attr_dict[{name!r}].type"

                if att.default is attr.NOTHING:
                    yield f'{name}: {type_name}'
                elif hasattr(att.default, 'factory'):
                    yield f'{name}: {type_name} = NOTHING'
                else:
                    yield f'{name}: {type_name} = attr_dict[{name!r}].default'

    # Generate source code for the definition of '__init__'

    # Get the parameters for '__init__' (e.g. 'item1: int, item2: float: 3.14, ...')
    # parameters = ', '.join(_parameters(attributes))  # type: # str
    # yield f'def __init__(self, {parameters}):'
    yield 'def __init__('
    yield '    self,'
    for param in _parameters(attributes):
        yield f'    {param},'
    yield '):'

    # Generate source code for 'self._content'
    yield '    self._content = {'
    for name, att in attributes.items():
        if not att.init:
            yield f"        {name!r}: None,"

        elif att.converter:
            converter = f'attr_dict[{name!r}].converter'  # type: str

            if att.default is attr.NOTHING:
                yield f'        {name!r}: {converter}({name}),'

            elif hasattr(att.default, 'factory'):
                assert att.default is not None  # TODO: Fix for mypy. Remote assert.

                if att.default.takes_self:
                    raise NotImplementedError
                else:
                    yield (f"        {name!r}: {converter}({name}) if {name} is not NOTHING "
                           f"else {converter}(attr_dict[{name!r}].default.factory()),")
            else:
                yield (f'        {name!r}: {converter}({name}),')

        else:
            if att.default is attr.NOTHING:
                yield f"        {name!r}: {name},"

            elif hasattr(att.default, 'factory'):
                assert att.default is not None  # TODO: Fix for mypy. Remote assert.

                if att.default.takes_self:
                    raise NotImplementedError
                else:
                    yield (f'        {name!r}: {name} if {name} is not NOTHING '
                           f'else attr_dict[{name!r}].default.factory(),')
            else:
                yield f"        {name!r}: {name},"

    yield '    }'
    yield ''

    # Generate source code for the validator(s)
    for name, att in attributes.items():
        validator = att.validator  # type: t.Optional[t.Callable]

        if not validator:
            continue

        name = att.name

        yield f'    attr_dict[{name!r}].validator(self, attr_dict[{name!r}], self._content[{name!r}])'

    if has_post_init:
        yield f'    self.__attrs_post_init__()'

    yield ''


def extract_modules_names(attributes: dict) -> t.Iterator[str]:
    """Get all the 'modules' used in 'attributes'."""
    for _, att in attributes.items():
        if att.type:

            module_name = att.type.__module__  # type: str

            if module_name != 'builtins':
                yield module_name


def _construct_init(attributes: dict, has_post_init: bool) -> t.Callable:
    """Create method '__init__' from a dictionary of `attr.Attribute` objects.

    :param attributes: dictionary of `attr.Attribute` objects.
    :param has_post_init: notified if method '__attrs_post_init__' is implemented.
    :return:
    """
    # Build the source code for __init__
    script = '\n'.join(_construct_source_init(attributes,
                                              has_post_init=has_post_init))

    # Create a unique filename based on the content of 'attributes'
    sha1 = hashlib.sha1(repr(attributes).encode("utf-8"))
    unique_filename = "<attrs generated init %s>" % sha1.hexdigest()

    # Get the names of all modules used in 'attributes'
    modules_by_name = set(extract_modules_names(attributes))  # type: t.Set[str]
    modules = {name: importlib.import_module(name) for name in modules_by_name}  # type: dict

    # Convert 'script' from `str` to `bytecode` for script
    globs = {"NOTHING": attr.NOTHING,
             "attr_dict": attributes,
             **modules}
    locs = {}  # type: dict

    bytecode = compile(source=script, filename=unique_filename, mode="exec")
    eval(bytecode, globs, locs)

    # Create the callable '__init__'
    __init__ = locs["__init__"]  # type: t.Callable

    # In order of debuggers like PDB being able to step through the code,
    # we add a fake linecache entry.
    # Note: this is copy/paste from `attr`
    linecache.cache[unique_filename] = (len(script), None, script.splitlines(True), unique_filename)  # type: ignore

    return __init__


def getter_factory(name: str) -> t.Callable:
    """Create a new 'getter' callable.

    This getter will be used in 'property'.
    """
    def _getter(ctx):
        """Getter."""
        return ctx._content[name]

    # Remove explicitly the documentation
    _getter.__doc__ = None

    return _getter


def setter_factory(att: attr.Attribute, readonly: bool) -> t.Callable:
    """Create a new 'setter' callable.

    This setter will be used in 'property'.
    """
    def _valid_setter(ctx, value):
        """Setter."""
        # Apply conversion (if needed)
        if att.converter:
            new_value = att.converter(value)
        else:
            new_value = value

        # Apply validation (if needed)
        if att.validator:
            # TODO: Call function 'attr.validator' with the keywords arguments ?
            att.validator(ctx, att, new_value)

        ctx._content[att.name] = new_value

    def _invalid_setter(ctx, _):
        """No setter."""
        raise RuntimeError(f"Cannot set attribute {att.name!r} in context {ctx!r}")

    # Select the applicable 'setter'
    if not readonly:
        wrapper = _valid_setter
    else:
        wrapper = _invalid_setter

    return wrapper


def _construct_properties(attributes: dict) -> t.Iterable[t.Tuple[str, property]]:
    """Build the properties based on 'attributes'.

    :param attributes:
    :return:


    Example::

        >>> attributes = {'item1': attr.Attribute(name='item1', ...),
        ...               'item2': attr.Attribute(name='item2', ...)}

        >>> list(_construct_properties(attributes))
        [('item1', <property object at 0x...), ('item2', <property object at 0x..)]
    """
    for name, att in attributes.items():
        if METADATA_KEY not in att.metadata:
            raise RuntimeError(f"Attribute {name} was not defined with `esapy_config.setting`")

        metadata = att.metadata[METADATA_KEY]  # type: MetadataSetting
        is_readonly = metadata.mode == SettingMode.RO

        # Create the 'getter', 'setter' and the documentation
        doc = metadata.doc
        fget = getter_factory(name=name)  # type: t.Callable
        fset = setter_factory(att=att, readonly=is_readonly)  # type: t.Callable
        fdel = None

        prop = property(fget=fget, fset=fset, fdel=fdel, doc=doc)

        yield name, prop


def config(
        maybe_cls: t.Optional[t.Type] = None,
        is_user_setting: t.Optional[bool] = None,
        mode: t.Optional[SettingMode] = None,
        has_repr=True,
        has_cmp=True,
        has_hash=None,
        has_slots=False,
        has_str=False,
):
    """Class decorator to build a `esapy_config` object.

    :param maybe_cls:
    :param is_user_setting: overwrite the parameter 'is_user_setting' in the setting(s).
    :param mode: overwrite the parameter 'mode' in the setting(s).
    :param has_repr: create a __repr__ method.
    :param has_cmp: create a __eq__, __ne__, __lt__, __le__, __gt__ and __ge__ methods.
    :param has_hash: create a __hash__ method.
    :param has_slots: create slots-style class.
    :param has_str: create a __str__ method.
    """
    def _wrapper(cls: t.Type):
        """TBW."""
        # Create a new class based on `attr`
        klass = attr.s(init=False, repr=has_repr, cmp=has_cmp,
                       hash=has_hash, slots=has_slots, str=has_str)(cls)

        has_post_init = hasattr(klass, '__attrs_post_init__')  # type: bool

        # Get all `attr.Attribute` objects from 'klass'
        attributes = attr.fields_dict(klass)  # type: dict

        if is_user_setting is not None or mode is not None:
            raise NotImplementedError

        # Create '__init__' and the 'properties'
        __init__ = _construct_init(attributes, has_post_init=has_post_init)  # type: t.Callable
        props = dict(_construct_properties(attributes))  # type: t.Dict[str, property]

        new_attributes = {
            '__init__': __init__,
            **props
        }  # type: t.Dict[str, t.Union[t.Callable, property]]

        # Bind the new attributes
        for name, prop in new_attributes.items():
            setattr(klass, name, prop)

        return klass

    if maybe_cls is None:
        return _wrapper
    else:
        return _wrapper(maybe_cls)

    return _wrapper
