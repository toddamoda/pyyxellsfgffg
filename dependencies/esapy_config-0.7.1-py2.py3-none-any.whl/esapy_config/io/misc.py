"""General function to read/write to/from a YAML content."""

import collections
import copy
import inspect
import logging
import platform
from enum import Enum

import attr
import typing as t
import yaml
from pathlib import Path

from esapy_config.util import lstrip_one_underscore
from ..converters import to_callable

try:
    # Use LibYAML library
    raise ImportError("This is not working properly with 'CSafeDumper'. Fix this !")        # TODO: Fix this
    from yaml import CSafeDumper as SafeDumper  # type: ignore
    from yaml import CSafeLoader as SafeLoader  # type: ignore
except ImportError:
    from yaml import SafeDumper  # noqa: F401
    from yaml import SafeLoader  # type: ignore


IS_PY37 = platform.python_version_tuple() >= ('3', '7', '0')  # type: bool

__all__ = ['from_yaml', 'to_yaml']


class MyLoader(SafeLoader):
    """Custom `SafeLoader` that constructs EsapyConfig objects.

    This class is not directly instantiated by user code, but instead is
    used to maintain the available constructor functions that are
    called when parsing a YAML stream.  See the `PyYaml documentation
    <http://pyyaml.org/wiki/PyYAMLDocumentation>`_ for details of the
    class signature.
    """

    def __init__(self, stream:  t.Union[str, t.IO], klass) -> None:
        """Create an instance to convert the YAML content into a EsapyConfig object.

        :param stream: str of file-like object
        :param klass:
        """
        super().__init__(stream)

        if not attr.has(klass):
            raise TypeError("Class %r was not create with 'EsapyConfig'" % klass)

        self._log = logging.getLogger(__name__)

        self._fields_lst = []       # type: list
        self._attr_to_check = []    # type: list
        self._flag_create_obj = False    # type: bool

        self._klass = klass  # type: t.Type

        self.prepare(klass=klass)

    @property
    def klass(self) -> t.Type:
        """TBW."""
        return self._klass

    # TODO: Add more comments
    def prepare(self, klass):
        """TBW.

        :param klass:
        :return:
        """
        assert attr.has(klass)

        # Extract the attributes from 'klass'
        fields = attr.fields_dict(klass)  # type: t.Dict[str, attr.Attribute]

        # Convert all keys '_XX' into 'XX'
        modified_fields = {lstrip_one_underscore(key): value
                           for key, value in fields.items()}  # type: t.Dict[str, attr.Attribute]

        self._fields_lst.append([klass, modified_fields])

        self._flag_create_obj = True

    # TODO: Rename this method.
    def _name_tbd(self, klass) -> None:
        """TBW."""
        # This class was built with `attr`
        self.prepare(klass=klass)
        self._attr_to_check.append([klass, None])

    def construct_object(self, node, deep=True):
        """Create a new object based on 'node'.

        :param node:
        :param deep:
        :return:
        """
        create_custom_obj = False
        if self._flag_create_obj:
            create_custom_obj = True

        if self._attr_to_check:
            # Check when the type for the 'node' is a `callable` or an optional `callable`
            klass, attribute = self._attr_to_check[0]
            if is_typing_optional_callable(attribute.type) or is_typing_callable(attribute.type):
                node.tag = '!function'

        # Get the object or the parameters that will be used to create the object.
        obj = super().construct_object(node, deep)

        if create_custom_obj:
            if isinstance(obj, dict):
                # Create the object based on keyword argument(s).
                kwargs = obj    # type: dict

                klass, fields = self._fields_lst[-1]

                self._log.debug('Check if an object of class %r can be built', klass)

                # Check if all compulsory 'values' are provided
                for key, value in fields.items():
                    if value.default == attr.NOTHING:
                        raise yaml.MarkedYAMLError(context_mark=node.start_mark,
                                                   context="Missing compulsory parameter %r" % key)

                # Create a new object based on 'kwargs'
                obj = klass(**kwargs)

        return obj

    def construct_sequence(self, node: yaml.SequenceNode, deep: bool = True) -> list:
        """Create a sequence of object(s) based on 'node'.

        :param node:
        :param deep:
        :return:
        """
        self._log.debug("Construct sequence")

        if self._flag_create_obj:
            # Create a custom sequence of objects.
            self._flag_create_obj = False

            if not isinstance(node, yaml.SequenceNode):
                raise yaml.constructor.ConstructorError(None, None,
                                                        f"expected a sequence node, but found {node.id}",
                                                        node.start_mark)

            # Make a copy of all attribute(s) to check
            current_fields = copy.deepcopy(self._fields_lst[-1])

            sequence = []   # type: list
            for child in node.value:
                self._fields_lst[-1] = copy.deepcopy(current_fields)
                self._flag_create_obj = True

                # Construct an object based on library 'attr'
                obj = self.construct_object(child, deep=deep)
                sequence.append(obj)

        else:
            sequence = super().construct_sequence(node, deep)

        return sequence

    def construct_mapping(self, node: yaml.MappingNode, deep: bool = True) -> dict:
        """Create a `dict` based on 'node'.

        :param node:
        :param deep:
        :return:
        """
        self._log.debug("Construct mapping")

        if self._flag_create_obj:
            # Create a custom `dict`
            self._flag_create_obj = False
            if isinstance(node, yaml.MappingNode):
                self.flatten_mapping(node)
            else:
                raise yaml.constructor.ConstructorError(None, None,
                                                        "expected a mapping node, but found %s" % node.id,
                                                        node.start_mark)

            mapping = {}        # type: dict
            for key_node, value_node in node.value:
                # Check 'key_node'
                argument, is_value_based_on_attr = self._check_mapping_key(deep, key_node)

                if not isinstance(argument, collections.abc.Hashable):
                    raise yaml.constructor.ConstructorError("while constructing a mapping", node.start_mark,
                                                            "found unhashable key", key_node.start_mark)

                # Check 'value_node'
                value = self._check_mapping_value(deep, is_value_based_on_attr, value_node)

                mapping[argument] = value
                assert len(self._fields_lst) > 0

        else:
            mapping = super().construct_mapping(node, deep)

        return mapping

    def _check_mapping_value(self,
                             deep: bool,
                             is_value_based_on_attr,
                             value_node: yaml.Node):
        """TBW.

        :param deep:
        :param is_value_based_on_attr:
        :param value_node:
        :return:
        """
        value = self.construct_object(value_node, deep=deep)

        # Check if argument's value is
        #  valid
        if is_value_based_on_attr:
            self._attr_to_check.pop()

        klass, attribute = self._attr_to_check[-1]

        if attribute.converter:
            value = attribute.converter(value)  # type: ignore

        validator = attribute.validator
        if callable(validator):
            self._log.debug("Check whether value: %r for attribute: %r is valid", value, attribute)
            try:
                validator(inst=None,  # type: ignore
                          attr=attribute,
                          value=value)
            except Exception as exc:
                # TODO: Check this
                self._log.debug("Exc: %r", exc)
                if hasattr(exc, 'args') and isinstance(exc.args, list):
                    msg = type(exc)(exc.args[0])
                else:
                    msg = exc

                raise yaml.MarkedYAMLError(context_mark=value_node.start_mark,
                                           context=f"Cannot validate value {value!r}",
                                           problem=str(msg))
        if is_value_based_on_attr:
            self._fields_lst.pop()
            # self._attr_to_check.pop()

        return value

    def _check_mapping_key(self,
                           deep: bool,
                           key_node: yaml.Node) -> tuple:
        """TBW.

        :param deep:
        :param key_node:
        :return:
        """
        # Check if the argument's name is valid
        argument = self.construct_object(key_node, deep=deep)  # type: str

        # Get all `attr.Attributes` object to (still) validate
        if not self._fields_lst:
            raise NotImplementedError
        klass, fields = self._fields_lst[-1]

        # Check if the parameter 'param_name' exists for 'klass'
        is_value_based_on_attr = False
        if argument not in fields:
            raise yaml.MarkedYAMLError(context_mark=key_node.start_mark,
                                       context="Unexpected argument %r" % argument)
        self._log.debug("Parameter %r exists in attribute: %r", argument, fields)

        # Extract the `attr.Attribute` object. It will be used to check the value of the parameter.
        attribute = fields[argument]  # type: attr.Attribute
        if self._attr_to_check:
            self._attr_to_check[-1] = [klass, attribute]
        else:
            self._attr_to_check.append([klass, attribute])

        attribute_type = attribute.type  # type: t.Optional[t.Type]
        if attribute_type is not None:
            if attr.has(attribute_type):
                self._name_tbd(klass=attribute_type)
                is_value_based_on_attr = True

            elif is_typing_optional(attribute_type):
                value_type = attribute_type.__args__[0]  # type: ignore

                if attr.has(value_type):
                    self._name_tbd(klass=value_type)
                    is_value_based_on_attr = True

            elif is_typing_union(attribute_type):
                raise NotImplementedError

            elif is_typing_list(attribute_type):
                args = attribute_type.__args__  # type: tuple
                if len(args) != 1:
                    raise NotImplementedError

                if attr.has(args[0]):
                    self._name_tbd(klass=args[0])
                    is_value_based_on_attr = True

            elif is_typing_dict(attribute_type):
                key_type, value_type = attribute_type.__args__  # type: ignore

                if attr.has(key_type):
                    raise NotImplementedError

                if attr.has(value_type):
                    raise NotImplementedError

        del fields[argument]

        return argument, is_value_based_on_attr

    def _include_constructor(self, node: yaml.ScalarNode):
        """TBW."""
        value = node.value  # type: str
        filename = Path(value).resolve()  # type: Path
        if not filename.exists():
            raise FileNotFoundError('File name does not exist: %s' % filename)

        with filename.open() as stream:
            result = from_yaml(stream, klass=self.klass)

        return result


def _function_constructor(loader: MyLoader, node: yaml.ScalarNode) -> t.Callable:
    """TBW."""
    func_name = loader.construct_scalar(node)   # type: str
    func = to_callable(func_name)               # type: t.Callable

    return func


MyLoader.add_constructor('!function', _function_constructor)
MyLoader.add_constructor('!include', MyLoader._include_constructor)


class MyDumper(SafeDumper):
    """Custom `SafeDumper`.

    This class is not directly instantiated by user code, but instead is
    used to maintain the available representer functions that are
    called when generating a YAML stream from an object.  See the
    `PyYaml documentation <http://pyyaml.org/wiki/PyYAMLDocumentation>`_
    for details of the class signature.
    """


def from_yaml(stream: t.Union[str, t.IO], klass):
    """Convert a YAML str (or file-like) into a new object from class `klass`.

    :param stream:
    :param klass:
    :return:
    """
    loader = MyLoader(stream, klass=klass)
    try:
        return loader.get_single_data()
    finally:
        loader.dispose()  # type: ignore


def _representer_attr_obj(dumper: MyDumper, obj):
    """Representer for dumper `MyDumper`.

    It convert an object into a PYYAML object.

    :param dumper:
    :param obj:
    :return:
    """
    if not attr.has(obj):
        raise TypeError(f"Object {obj!r} was not create with 'EsapyConfig' or 'attr'")

    # Get the current state of 'obj'
    states = attr.asdict(obj, recurse=False)  # type: dict

    ordered_states = []  # type: t.List[t.Tuple[str, t.Any]]

    # Get a list of all attributes in 'obj'
    attributes = obj.__attrs_attrs__  # type: t.Tuple[attr.Attribute]

    for att in attributes:        # type: attr.Attribute
        if not att.init:
            continue

        # TODO: do not use 'lstrip_one_underscore' in the future
        value = states[att.name]

        if value == att.default:
            continue

        name = lstrip_one_underscore(att.name)  # type: str
        ordered_states.append((name, value))

    return dumper.represent_mapping(tag='tag:yaml.org,2002:map',
                                    mapping=ordered_states,
                                    flow_style=dumper.default_flow_style)


def _representer_enum(dumper: MyDumper, obj):
    """Representer for dumper `MyDumper`.

    It convert an object into a PYYAML object.

    :param dumper:
    :param obj:
    :return:
    """
    return dumper.represent_str(data=obj.value)


def _representer_callable(dumper: MyDumper, obj):
    """Representer for dumper `MyDumper`.

    It convert an object into a PYYAML object.

    :param dumper:
    :param obj:
    :return:
    """
    name = f'{obj.__module__}.{obj.__qualname__}'

    return dumper.represent_scalar(tag='tag:yaml.org,2002:str',
                                   value=name)


MyDumper.add_representer(type(lambda: None), _representer_callable)


def is_typing_callable(klass) -> bool:
    """Check if 'klass' is a `typing.Callable` object."""
    if IS_PY37:
        # Python 3.7+
        return hasattr(klass, '__origin__') and klass.__origin__ is collections.abc.Callable
    else:
        # Python 3.6
        return hasattr(klass, '__extra__') and klass.__extra__ is collections.abc.Callable


def is_typing_union(klass) -> bool:
    """Check if 'obj' is a `typing.Union` object."""
    return hasattr(klass, '__origin__') and klass.__origin__ is t.Union


def is_typing_optional(klass) -> bool:
    """Check if 'obj' is a `typing.Optional` object."""
    if is_typing_union(klass) and len(klass.__args__) == 2:
        _, second = klass.__args__
        return issubclass(second, type(None))
    else:
        return False


def is_typing_optional_callable(klass) -> bool:
    """Check if 'obj' is a `typing.Optional[typing.Callable] object."""
    if is_typing_optional(klass):
        first, _ = klass.__args__
        return is_typing_callable(first)
    else:
        return False


def is_typing_list(klass) -> bool:
    """Check if 'obj' is a `typing.List` object."""
    if IS_PY37:
        # Python 3.7
        return hasattr(klass, '__origin__') and klass.__origin__ is list
    else:
        return hasattr(klass, '__extra__') and klass.__extra__ is list


def is_typing_dict(klass) -> bool:
    """Check if 'obj' is a `typing.Dict` object."""
    if IS_PY37:
        # Python 3.7
        return hasattr(klass, '__origin__') and klass.__origin__ is dict
    else:
        return hasattr(klass, '__extra__') and klass.__extra__ is dict


def create_representer(klass) -> None:
    """Create a 'representer' for class 'klass'.

    :param klass:
    :return:
    """
    logging.debug("Try to create representer for klass %r", klass)

    if not inspect.isclass(klass) and not isinstance(klass, t.Callable):  # type: ignore
        raise TypeError(f"Expecting a class for {klass!r}")

    if attr.has(klass):
        # Create the representer only for classes generated by 'EsapyConfig' or 'attr'.
        logging.debug("Create representer for klass %r", klass)
        MyDumper.add_representer(klass, _representer_attr_obj)

        fields = attr.fields_dict(klass)    # type: ignore
        for value in fields.values():       # type: attr.Attribute
            vtype = value.type              # type: t.Optional[t.Type]

            if vtype is None:
                continue

            # Check if 'vtype' is a 'typing.Union' type.
            if is_typing_union(vtype):
                for union_type in vtype.__args__:
                    # TODO: Improve this. Compare to `NoneType`. Maybe create a class for the comparison.
                    if union_type is not None:
                        create_representer(klass=union_type)

            else:
                create_representer(klass=vtype)

    elif is_typing_list(klass):
        value_type = klass.__args__[0]  # type: ignore
        create_representer(klass=value_type)

    elif is_typing_callable(klass):
        args = klass.__args__  # type: tuple
        if args:
            # E.g. `klass = typing.Callable[[int], float]` ==> params = (int, ) and ret = float
            *params, ret = args
            raise NotImplementedError
        else:
            MyDumper.add_representer(klass, _representer_callable)

    elif issubclass(klass, Enum):
        logging.debug("Create representer for Enum klass %r", klass)
        MyDumper.add_representer(klass, _representer_enum)


def to_yaml(obj) -> str:
    """Convert/serialize an object into a YAML stream.

    :param obj:
    :return:
    """
    if not attr.has(obj):
        raise TypeError("Expecting an objet created with 'esapy_config' or 'attr'")

    logging.debug("Convert obj type: %r into a YAML stream", type(obj))

    create_representer(klass=type(obj))

    return yaml.dump(obj, Dumper=MyDumper, default_flow_style=False)
