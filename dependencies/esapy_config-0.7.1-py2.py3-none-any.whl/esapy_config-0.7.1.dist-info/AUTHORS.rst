====================
esapy_config authors
====================

* `Hans Smit <Hans Smit@esa.int>`_
* `Frédéric Lemmel <frederic.lemmel@esa.int>`_
